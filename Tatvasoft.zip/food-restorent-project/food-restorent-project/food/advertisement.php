<div class="abt-section mb-150">
		<div class="container">
			<div class="row">
				<div class="col-lg-6 col-md-12">
					<div class="abt-bg">
						<a href="https://www.youtube.com/watch?v=DBLlFWYcIGQ" class="video-play-btn popup-youtube"><i class="fas fa-play"></i></a>
					</div>
				</div>
				<div class="col-lg-6 col-md-12">
					<div class="abt-text">
						<p class="top-sub">Since Year 2021</p>
						<h2>We are <span class="orange-text">Crazy Bite Food</span></h2>
						<p>Etiam vulputate ut augue vel sodales. In sollicitudin neque et massa porttitor vestibulum ac vel nisi. Vestibulum placerat eget dolor sit amet posuere. In ut dolor aliquet, aliquet sapien sed, interdum velit. Nam eu molestie lorem.</p>
						<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Sapiente facilis illo repellat veritatis minus, et labore minima mollitia qui ducimus.</p>
						<a href="about.php" class="boxed-btn mt-4">know more</a>
					</div>
				</div>
			</div>
		</div>
	</div>

	The Original is a revered Denver-based diner from Sage Restaurant Concepts. Built on the idea of reinventing the place where locals go, this neighborhood eatery satisfies diners with imaginative twists. Their website is a clear example of bringing the restaurant experience online, with quirky illustrations of malts and t-bone steaks throughout which brings the website to life. The navy border keeps guests focused while browsing menus and new happenings inside the restaurant. The highlighted “Reservations” button is optimized to prompt visitors to book a table, thus turning an online guest into a paying customer.