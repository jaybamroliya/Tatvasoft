<div class="footer-area" style="background-color: white;">
		<div class="container">
			<div class="row">
				<div class="col-lg-3 col-md-6">
					<div class="footer-box about-widget">
						<h2 class="widget-title" style="color: black;">About us</h2>
						<p style="color: black;">Although a great restaurant experience must include great food, a bad restaurant experience can be achieved through bad service alone. Ideally, service is invisible. You notice it only when something goes wrong.</p>
					</div>
				</div>
				<div class="col-lg-3 col-md-6">
					<div class="footer-box get-in-touch">
						<h2 class="widget-title" style="color: black;">Get in Touch</h2>
						<ul>
							<li style="color: black;">tatvasoft, gujarat</li>
							<li style="color: black;">support@tatvasoft.com</li> 
							<li style="color: black;">+91 7433035294</li>
							<li style="color: black;">+91 6353151394</li>
						</ul>
					</div>
				</div>
				<div class="col-lg-3 col-md-6">
					<div class="footer-box pages">
						<h2 class="widget-title" style="color: black;">Pages</h2>
						<ul>
							<li><a href="index.php" style="color: black;">Home</a></li>
							<li><a href="about.php" style="color: black;">About</a></li>
							<li><a href="shop.php" style="color: black;">Shop</a></li>
							<li><a href="news.php" style="color: black;">News</a></li>
							<li><a href="contact.php" style="color: black;">Contact</a></li>
						</ul>
					</div>
				</div>
				<!-- <div class="col-lg-3 col-md-6">
					<div class="footer-box subscribe">
						<h2 class="widget-title">Subscribe</h2>
						<p>Subscribe to our mailing list to get the latest updates.</p>
						<form action="index.php">
							<input type="email" placeholder="Email">
							<button type="submit"><i class="fas fa-paper-plane"></i></button>
						</form>
					</div>
				</div> -->
			</div>
		</div>
	</div>