<div class="menu-sidebar__content js-scrollbar1">
                <nav class="navbar-sidebar">
                    <ul class="list-unstyled navbar__list">
                        <li class="active has-sub">
                            <a class="js-arrow" href="dashboard.php">
                                <i class="fas fa-tachometer-alt"></i>Dashboard</a>
                        </li>
                        <li>
                            <a href="banner.php">
                                <i class="fas fa-sliders"></i>BANNER</a>
                        </li>
                        <li>
                            <a href="product.php">
                                <i class="fas fa-shopping-cart"></i>PRODUCTS</a>
                        </li>
                        <li>
                            <a href="blog.php">
                                <i class="fas fa-calendar-alt"></i>BLOG</a>
                        </li>
                        <li>
                            <a href="oreder.php">
                                <i class="fas fa-truck"></i>ORDER</a>
                        </li>
                    </ul>
                </nav>
            </div>